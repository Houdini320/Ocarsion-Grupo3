import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SubirCocheAdminPage } from './subir-coche-admin';

@NgModule({
  declarations: [
    SubirCocheAdminPage,
  ],
  imports: [
    IonicPageModule.forChild(SubirCocheAdminPage),
  ],
})
export class SubirCocheAdminPageModule {}
