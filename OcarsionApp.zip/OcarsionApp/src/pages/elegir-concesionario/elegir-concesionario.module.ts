import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ElegirConcesionarioPage } from './elegir-concesionario';

@NgModule({
  declarations: [
    ElegirConcesionarioPage,
  ],
  imports: [
    IonicPageModule.forChild(ElegirConcesionarioPage),
  ],
})
export class ElegirConcesionarioPageModule {}
